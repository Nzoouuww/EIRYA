import { Test } from '@nestjs/testing';
import { ConflictException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { Role } from '@prisma/client';
import { AuthService } from './auth.service';
import { PrismaService } from '../prisma/prisma.service';

describe('AuthService', () => {
  let authService: AuthService;
  let prisma: { user: any; professionalProfile: any };

  beforeEach(async () => {
    prisma = {
      user: {
        findUnique: jest.fn(),
        create: jest.fn(),
      },
      professionalProfile: {
        findUnique: jest.fn().mockResolvedValue(null), // slug jamais pris -> pas de collision
        create: jest.fn(),
      },
    };

    const moduleRef = await Test.createTestingModule({
      providers: [
        AuthService,
        { provide: PrismaService, useValue: prisma },
        { provide: JwtService, useValue: { sign: () => 'fake-jwt' } },
      ],
    }).compile();

    authService = moduleRef.get(AuthService);
  });

  it('refuse une inscription avec un email déjà utilisé', async () => {
    prisma.user.findUnique.mockResolvedValue({ id: '1', email: 'ines@example.com' });

    await expect(
      authService.register({
        email: 'ines@example.com',
        password: 'password123',
        role: Role.PROFESSIONAL,
      }),
    ).rejects.toThrow(ConflictException);
  });

  it('crée un ProfessionalProfile associé lors de l’inscription d’une pro', async () => {
    prisma.user.findUnique.mockResolvedValue(null);
    prisma.user.create.mockResolvedValue({
      id: 'user-1',
      email: 'ines@example.com',
      role: Role.PROFESSIONAL,
    });

    await authService.register({
      email: 'ines@example.com',
      password: 'password123',
      role: Role.PROFESSIONAL,
    });

    expect(prisma.professionalProfile.create).toHaveBeenCalledTimes(1);
    expect(prisma.professionalProfile.create).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ userId: 'user-1', slug: 'ines' }),
      }),
    );
  });

  it('ne crée pas de ProfessionalProfile pour une cliente', async () => {
    prisma.user.findUnique.mockResolvedValue(null);
    prisma.user.create.mockResolvedValue({
      id: 'user-2',
      email: 'sarah@example.com',
      role: Role.CLIENT,
    });

    await authService.register({
      email: 'sarah@example.com',
      password: 'password123',
      role: Role.CLIENT,
    });

    expect(prisma.professionalProfile.create).not.toHaveBeenCalled();
  });
});
