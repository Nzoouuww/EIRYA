import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class UsersService {
  constructor(private prisma: PrismaService) {}

  async findByIdWithProfile(id: string) {
    const user = await this.prisma.user.findUnique({
      where: { id },
      include: { professionalProfile: true },
    });
    if (!user) throw new NotFoundException('Utilisateur introuvable');

    // On ne renvoie jamais le hash du mot de passe, même en interne.
    const { passwordHash, ...safeUser } = user;
    return safeUser;
  }
}
