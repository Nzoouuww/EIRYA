# EIRYA — Monorepo (Semaine 1-2 : setup, auth, schéma DB)

Ce que contient cette livraison :

- `services/api` — backend NestJS + Prisma, avec un module **auth** fonctionnel (inscription/connexion, JWT, rôles).
- `apps/mobile` — squelette Expo Router avec la navigation par rôle (`(auth)` / `(pro)` / `(client)`) et un écran par item de la liste "Écrans nécessaires (MVP)" du document d'analyse — pour l'instant en stub, à remplir écran par écran dans les prochaines itérations.
- Schéma Prisma complet du MVP (users, professional_profiles, services, portfolio_items, availability_rules, blocked_slots, client_records, appointments, payments, refunds, reviews, notifications).
- CI GitHub Actions basique (build + tests de l'API).

## ⚠️ Important : ce sandbox n'a pas d'accès réseau

Je n'ai pas pu exécuter `npm install`, `prisma generate` ni les tests ici — le conteneur dans lequel je travaille n'a pas de sortie internet. Le code est donc écrit et cohérent, mais **pas encore exécuté**. Tu dois lancer les commandes ci-dessous en local pour vérifier que tout tourne.

## Démarrer l'API en local

```bash
cd services/api
cp .env.example .env
# éditer .env : DATABASE_URL vers un Postgres local (ou Supabase), JWT_SECRET

npm install
npx prisma migrate dev --name init   # crée les tables à partir de prisma/schema.prisma
npm run start:dev
```

L'API démarre sur `http://localhost:3000`.

### Tester l'authentification

```bash
# Inscription d'une professionnelle
curl -X POST http://localhost:3000/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"ines@example.com","password":"password123","role":"PROFESSIONAL"}'

# -> renvoie { accessToken, user }

# Connexion
curl -X POST http://localhost:3000/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"ines@example.com","password":"password123"}'

# Route protégée (remplacer TOKEN par l'accessToken reçu)
curl http://localhost:3000/users/me -H "Authorization: Bearer TOKEN"
```

`POST /auth/register` avec `role: "PROFESSIONAL"` crée automatiquement une `ProfessionalProfile` (avec un `slug` unique pour le futur lien `eirya.app/{slug}`) — c'est volontairement l'onboarding **produit**, séparé de l'onboarding **paiement** (Stripe Connect, à brancher plus tard, voir `paymentsEnabled`/`stripeAccountId` dans le schéma).

### Lancer les tests

```bash
cd services/api
npm test
```

Le fichier `src/auth/auth.service.spec.ts` vérifie : refus d'un email déjà pris, création automatique du `ProfessionalProfile` pour une pro, absence de cette création pour une cliente.

## Démarrer l'app mobile en local

```bash
cd apps/mobile
npm install
npm run start
```

Ouvre ensuite l'app avec Expo Go ou un simulateur. Pour l'instant les écrans sont des stubs (juste un titre) — la prochaine étape logique est de brancher l'écran de connexion sur `POST /auth/login` et de router vers `(pro)` ou `(client)` selon `user.role`.

## Prochaines étapes (suite du plan section 13)

1. Écran d'inscription/connexion mobile branché sur l'API (`(auth)/login.tsx`, `(auth)/register.tsx`).
2. Module `professionals` côté API : édition du profil, création de prestations, upload portfolio.
3. Module `availability` : règles d'horaires + créneaux bloqués + calcul des créneaux disponibles.
4. Module `appointments` : création de réservation avec vérification anti-double-booking.
5. Intégration Stripe Connect (onboarding paiement + acompte).

Je n'ai volontairement rien codé au-delà du MVP validé (pas de chat, pas de CRM, pas d'IA) — voir `/areas/eirya.md` pour le détail des décisions déjà validées.
