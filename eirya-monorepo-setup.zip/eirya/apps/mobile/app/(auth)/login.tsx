import { View, Text } from 'react-native';

// TODO : formulaire email/mot de passe -> POST /auth/login -> stocker accessToken
// -> rediriger vers (pro) ou (client) selon user.role
export default function LoginScreen() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>EIRYA — Connexion</Text>
    </View>
  );
}
