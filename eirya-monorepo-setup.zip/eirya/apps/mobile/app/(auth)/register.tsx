import { View, Text } from 'react-native';

// TODO : choix du rôle (PROFESSIONAL/CLIENT) -> POST /auth/register
// Pour une pro : enchaîner directement sur l'onboarding produit (profil/prestations/horaires),
// la vérification paiement (Stripe) reste une étape séparée, plus tard.
export default function RegisterScreen() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>EIRYA — Créer un compte</Text>
    </View>
  );
}
