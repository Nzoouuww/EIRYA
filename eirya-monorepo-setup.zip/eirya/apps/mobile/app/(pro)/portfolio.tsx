import { View, Text } from 'react-native';

// Écran pro : portfolio — à implémenter (voir écrans MVP §9 du document d'analyse)
export default function ProPortfolioScreen() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Pro — portfolio</Text>
    </View>
  );
}
