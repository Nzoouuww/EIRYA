import { View, Text } from 'react-native';

// Écran pro : agenda — à implémenter (voir écrans MVP §9 du document d'analyse)
export default function ProAgendaScreen() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Pro — agenda</Text>
    </View>
  );
}
