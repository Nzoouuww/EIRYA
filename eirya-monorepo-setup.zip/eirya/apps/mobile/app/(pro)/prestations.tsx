import { View, Text } from 'react-native';

// Écran pro : prestations — à implémenter (voir écrans MVP §9 du document d'analyse)
export default function ProPrestationsScreen() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Pro — prestations</Text>
    </View>
  );
}
