import { View, Text } from 'react-native';

// Écran pro : profil — à implémenter (voir écrans MVP §9 du document d'analyse)
export default function ProProfilScreen() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Pro — profil</Text>
    </View>
  );
}
