import { View, Text } from 'react-native';

// Écran pro : dashboard — à implémenter (voir écrans MVP §9 du document d'analyse)
export default function ProDashboardScreen() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Pro — dashboard</Text>
    </View>
  );
}
