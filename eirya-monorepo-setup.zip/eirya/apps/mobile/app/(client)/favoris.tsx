import { View, Text } from 'react-native';

// Écran cliente : favoris — à implémenter (voir écrans MVP §9 du document d'analyse)
export default function ClientFavorisScreen() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Cliente — favoris</Text>
    </View>
  );
}
