import { View, Text } from 'react-native';

// Écran cliente : decouvrir — à implémenter (voir écrans MVP §9 du document d'analyse)
export default function ClientDecouvrirScreen() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Cliente — decouvrir</Text>
    </View>
  );
}
