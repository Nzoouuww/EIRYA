import { View, Text } from 'react-native';

// Écran cliente : profil — à implémenter (voir écrans MVP §9 du document d'analyse)
export default function ClientProfilScreen() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Cliente — profil</Text>
    </View>
  );
}
