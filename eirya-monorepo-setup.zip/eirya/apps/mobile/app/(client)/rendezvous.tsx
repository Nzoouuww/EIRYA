import { View, Text } from 'react-native';

// Écran cliente : rendezvous — à implémenter (voir écrans MVP §9 du document d'analyse)
export default function ClientRendezvousScreen() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Cliente — rendezvous</Text>
    </View>
  );
}
