import { Tabs } from 'expo-router';

export default function ClientTabsLayout() {
  return (
    <Tabs>
      <Tabs.Screen name="decouvrir" options={{ title: 'Découvrir' }} />
      <Tabs.Screen name="favoris" options={{ title: 'Favoris' }} />
      <Tabs.Screen name="rendezvous" options={{ title: 'Rendez-vous' }} />
      <Tabs.Screen name="profil" options={{ title: 'Profil' }} />
    </Tabs>
  );
}
