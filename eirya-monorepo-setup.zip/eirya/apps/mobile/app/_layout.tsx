import { Stack } from 'expo-router';

// Layout racine : redirige ensuite vers (auth), (pro) ou (client) selon
// le rôle renvoyé par POST /auth/login (à brancher avec un contexte d'auth réel,
// pour l'instant Stack simple pour poser la structure).
export default function RootLayout() {
  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="(auth)" />
      <Stack.Screen name="(pro)" />
      <Stack.Screen name="(client)" />
    </Stack>
  );
}
